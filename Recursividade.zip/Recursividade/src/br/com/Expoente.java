package br.com;

public class Expoente {
	static int x = 0;
	static int resultado = 1;
	public static void main(String[] args) {

		System.out.println(exponencial(3, 3));

	}
	
	public static int exponencial(int base, int exp) {
		x = exp;
		
		if(exp == 0) {
			return 1;
		}else if(exp == 1) {
			return base;
		}else if(base == 1) {
			return 1;
		}else if(base == 0){
			return 0;
		}else if((base == 0) && (exp == 0)) {
			System.out.println("0^0 !!!");
		}
		
		if(exp > 0) {
			for(int i = x; i >= 1; i-- ) {
				resultado = resultado * base;
				x--;
			}
		}else {
			for(int i = 1; i <= x; i++ ) {
				resultado = resultado / base;
				x++;
			}
		}
		
		
		return resultado;
	}
}
