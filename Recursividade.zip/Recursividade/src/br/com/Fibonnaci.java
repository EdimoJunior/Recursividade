package br.com;

public class Fibonnaci {

	public static void main(String[] args) {

		System.out.println(fibonaci(7));

	}
	public static int fibonaciRec(int n) {
		if(n == 0) {
			return 0;
		} else {
			if (n == 1) {
				return 1;
			}else {
				return fibonaciRec(n-1) + fibonaciRec(n-2);
			}
		}
	}
	
	public static int fibonaci(int n) {
		//n = n-1;
		int a = 0, b = 1, c = 1;
		if(n == 0) {
			return 0;
		}else if(n == 1) {
			return 1;
		}
		for(int i = 0; i < n; i++) {
			a = b;
			b = c;
			c = a + b;
		}
		return c;
	}
}
