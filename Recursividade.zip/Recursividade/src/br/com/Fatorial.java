package br.com;

public class Fatorial {
	
	static int x = 0;
	static int resultado = 1;
	public static void main(String[] args) {

		System.out.println(fatorial(3));
		
	}
	
	
	public static int fatorial(int n) {
		x = n;
		for(int i = 1;  i < n; i++) {
			x = x * (n - i);
		}
		return x;
	}
	
	public static int fatorialRec(int n) {
		if(n == 1) {
			return 1;
		}else {
			return n*fatorialRec(n-1);
		}
	}

}

